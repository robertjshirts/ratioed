import process from 'node:process';globalThis._importMeta_={url:import.meta.url,env:process.env};export { w as handler } from './chunks/runtime.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import '@iconify/utils';
import 'consola/core';
import 'module';
import 'node:url';
import 'ipx';
//# sourceMappingURL=index.mjs.map
