import{_ as e,c as t,o as n}from"./C6-mQCkJ.js";const c={};function o(r,s){return n(),t("div",null,"feature in development")}const _=e(c,[["render",o]]);export{_ as default};
