import{r as s}from"./C6-mQCkJ.js";const u=()=>{var e;return(e=s().$supabase)==null?void 0:e.client};export{u};
